#include <stdio.h>
int i=10;
void main()
{
int i =20,n;
for(n=0;n<=i;n++)
{
int i=10;
i++;
}
printf("%d", i);
}
