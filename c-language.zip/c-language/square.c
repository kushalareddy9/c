#include <stdio.h>
int main ()
{
int l,b,area;
printf("enter lenght of the rectangle");
scanf("%d",&l);
printf("enter breadth of the rectangle");
scanf("%d",&b);
area=l*b;
printf("the area of a rectangle=%d\n",area);
}
