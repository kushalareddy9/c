#include <stdio.h>
int main()
{
float C,converstionF;
printf("the temperature of a body in celsius");
scanf("%f",&C);
converstionF=C*9/5+32;
printf("the temperature of a body in fahrenheit=%f\n",converstionF);
}
