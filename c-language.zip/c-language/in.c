#include<stdio.h>
int main()
{
int i=1/2;
printf("%d",i);
}
