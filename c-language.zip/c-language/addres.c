#include<stdio.h>
int main()
{
printf("my name is:varshini\n");
printf("my address id\t:amrita school of engineering\n");
printf("bangalore\n");
}
