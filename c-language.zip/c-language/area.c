#include<stdio.h>
#define pi 3.14
int main()
{
int a;
float circle;
printf("enter a value:");
scanf("%d",&a);
circle=pi*a*a;
printf("area of circle=%f\n",circle);
}
