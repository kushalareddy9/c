#include <stdio.h>
int main()
{
int height;
printf("Enter person height");
scanf("%d",&height);
printf("My height is %d\n", height);
}
