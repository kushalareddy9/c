#include<stdio.h>
int main()
{
int s1,e1,m1,m2,p1,c1,totalmarks;
printf("enter your marks of\n");
printf("s1=\n");
scanf("%d",&s1);
printf("e1=\n");
scanf("%d",&e1);
printf("m1=\n");
scanf("%d",&m1);
printf("m2=\n");
scanf("%d",&m2);
printf("p1=\n");
scanf("%d",&p1);
printf("c1=\n");
scanf("%d",&c1);
totalmarks=s1+e1+m1+m2+p1+c1;
printf("total marks obtained =%d\n",totalmarks);
}
