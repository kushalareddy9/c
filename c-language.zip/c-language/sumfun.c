#include<stdio.h>
int main()
{
int sum(int,int);
printf("sum=%d\n",sum(10,20));
}
int sum(int a,int b)
{
return a+b;
}
