#include<stdio.h>
main()
{
printf("welcome to C programming");
}

