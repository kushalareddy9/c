#include<stdio.h>
int main()
{
int a;
printf("enter a value:");
scanf("%d",&a);
if(a%4==0)
printf("it is a leap year");
else
printf("it is a non leap year");
}
