#include<stdio.h>
int main()
{
int a,b,sum,diff,mul,div;
printf("enter a and b values");
scanf("%d%d",&a,&b);
sum=a+b;
diff=a-b;
mul=a*b;
div=a/b;
printf("the answers are %d\n%d\n%d\n%d\n",sum,diff,mul,div);
}
