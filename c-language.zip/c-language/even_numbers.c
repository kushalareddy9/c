#include<stdio.h>
int main()
{
int i=1;
while(i<=50)
{
if(i%2 == 0)
i++;
printf("%d\n",i);
}
}
