#include<stdio.h>
#define pi 3.14
int main()
{
int r;
float circumcentre;
printf("enter r value:");
scanf("%d",&r);
circumcentre=2*pi*r;
printf("circumcentre of a circle=%f\n",circumcentre);
}

