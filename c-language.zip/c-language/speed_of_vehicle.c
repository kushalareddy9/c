#include<stdio.h>
int main()
{
int d,t,speed;
printf("Enter values of distance and time:");
scanf("%d%d",&d,&t);
speed=d/t;
printf("speed of vehicle=%d\n",speed);
}
