#include<stdio.h>
int main()
{
printf("IPE marks memo:\n");
printf("sanskrit : 99\n");
printf("english : 89\n");
printf("maths A : 73\n");
printf("maths B : 75\n");
printf("physics : 60\n");
printf("chemistry : 59\n");
}
