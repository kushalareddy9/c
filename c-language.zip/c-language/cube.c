#include <stdio.h>
int main()
{
int a,area;
printf("the side length of a cube");
scanf("%d",&a);
area=a*a*a;
printf("the area of a cube=%d\n",area);
}
