#include<stdio.h>
int main()
{
float c,convertionF;
printf("enter celsius value:\n");
scanf("%f",&c);
convertionF=9*c/5+32;
printf("F value =%f\n",convertionF);
}
