#include<stdio.h>
int main()
{
int s1,s2,s3,add;
printf("enter three items prices:\n");
scanf("%d%d%d",&s1,&s2,&s3);
add=s1+s2+s3;
printf("total amount to be paid is %d\n",add);
}
