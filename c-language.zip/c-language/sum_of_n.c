#include<stdio.h>
int main()
{
int n,natural;
printf("enter n value");
scanf("%d",&n);
natural=n*(n+1)/2;
printf("the sum of n natural numbers are %d\n",natural);
}
