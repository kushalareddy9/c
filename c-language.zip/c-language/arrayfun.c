#include<stdio.h>
int main()
{
int i,marks;
for(i=1;i<=5;i++)
{
printf("Enter marks\t");
scanf("%d\n",&marks);
printf("%d\n",marks);
}
}
