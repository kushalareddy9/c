#include<stdio.h>
int welcome();
int main()
{
printf("Before welcome\n");
welcome();
printf("after welcome\n");
}

int welcome()
{
printf("welcome to c\n");
}
